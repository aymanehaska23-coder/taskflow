import { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import type { RootState } from '../store';
import { logout } from '../features/auth/authSlice';
import useProjects from '../hooks/useProjects';
import HeaderMUI from '../components/HeaderMUI';
import Sidebar from '../components/Sidebar';
import MainContent from '../components/MainContent';
import ProjectForm from '../components/ProjectForm';
import styles from './Dashboard.module.css';
export default function Dashboard() {
const dispatch = useDispatch();
const { user } = useSelector((state: RootState) => state.auth);
const { projects, columns, loading, addProject } = useProjects();
const [sidebarOpen, setSidebarOpen] = useState(true);
const [showForm, setShowForm] = useState(false);

// Test temporaire pour observer la protection JSX
const dangerousName = '<img src=x onerror=alert("HACK")>';

if (loading) return <div className={styles.loading}>Chargement...</div>;
return (
<div className={styles.layout}>
<HeaderMUI
title="TaskFlow"
onMenuClick={() => setSidebarOpen(p => !p)}
userName={user?.name}
onLogout={() => dispatch(logout())}
/>
<p>{dangerousName}</p>
<div className={styles.body}>
<Sidebar projects={projects} isOpen={sidebarOpen} />
<div className={styles.content}>
<div className={styles.toolbar}>
{!showForm ? (
<button className={styles.addBtn}
onClick={() => setShowForm(true)}>
+ Nouveau projet
</button>
) : (
<ProjectForm
submitLabel="Créer"
onSubmit={(name: string, color: string) => {
  addProject(name, color);
  setShowForm(false);
}}
onCancel={() => setShowForm(false)}
/>
)}
</div>
<MainContent columns={columns} />
</div>
</div>
</div>
);
}