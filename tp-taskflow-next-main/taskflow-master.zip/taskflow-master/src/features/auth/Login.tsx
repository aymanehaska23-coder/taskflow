import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import type { RootState } from '../../store';
import { loginStart, loginSuccess, loginFailure } from './authSlice';
import styles from './Login.module.css';
export default function Login() {
  const dispatch = useDispatch();
  const { loading, error } = useSelector((state: RootState) => state.auth);
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
async function handleSubmit(e: React.FormEvent) {
e.preventDefault();
dispatch(loginStart());
try {
const res = await fetch(
`http://localhost:4000/users?email=${email}`
);
const users = await res.json();
if (users.length === 0 || users[0].password !== password) {
dispatch(loginFailure('Email ou mot de passe incorrect'));
return;
}
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const { password: _password, ...user } = users[0];
// Générer un faux token JWT
const fakeToken = btoa(JSON.stringify({
  userId: user.id,
  email: user.email,
  role: 'admin',
  exp: Date.now() + 3600000 // expire dans 1h
}));
dispatch(loginSuccess({ user, token: fakeToken }));
navigate('/dashboard');
} catch {
dispatch(loginFailure('Erreur de connexion au serveur'));
}
}
return (
<div className={styles.container}>
<form className={styles.form} onSubmit={handleSubmit}>
<h1 className={styles.title}>TaskFlow</h1>
<p className={styles.subtitle}>Connectez-vous pour continuer</p>
{error && <div className={styles.error}>{error}</div>}
<input
type="email"
placeholder="Email"
value={email}
onChange={e => setEmail(e.target.value)}
className={styles.input}
required
/>
<input
type="password"
placeholder="Mot de passe"
value={password}
onChange={e => setPassword(e.target.value)}
 className={styles.input}
 required
/>
<button
type="submit"
className={styles.button}
 disabled={loading}
>
 {loading ? 'Connexion...' : 'Se connecter'}
</button>
</form>
</div>
);
}